package Questao01pt2.Fabrics;

import java.util.Date;

public abstract class Pizzaria {
    public abstract PizzaioloFabric criaPizzaiolo(Date date);
}