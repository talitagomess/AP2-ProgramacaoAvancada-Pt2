package Questao01pt2.Products;

public class CalzonePresunto implements Calzone {

    @Override
    public void getIngredientes() {
        System.out.println("queijo + presunto + tomate");
    }
    
}