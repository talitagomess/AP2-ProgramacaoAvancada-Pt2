package Questao01pt2.Products;

public interface Calzone {
    public void getIngredientes();
}