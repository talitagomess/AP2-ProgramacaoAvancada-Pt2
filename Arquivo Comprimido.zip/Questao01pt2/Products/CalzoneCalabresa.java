package Questao01pt2.Products;

public class CalzoneCalabresa implements Calzone {

    @Override
    public void getIngredientes() {
        System.out.println("queijo + calabresa + tomate");
    }
    
}