package Questao01pt2.Products;

public class PizzaCalabresa implements Pizza {

    @Override
    public void getIngredientes() {
        System.out.println("queijo + calabresa + tomate");
    }
    
}