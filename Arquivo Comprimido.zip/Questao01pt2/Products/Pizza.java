package Questao01pt2.Products;

public interface Pizza {
    public void getIngredientes();
}