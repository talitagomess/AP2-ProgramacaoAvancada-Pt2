package Questao01.Fabrics;
import Questao01.Products.*;

public abstract class OutPutFabric {
    public abstract HelloWorld criarHello();
}