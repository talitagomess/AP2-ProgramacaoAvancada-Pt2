package Questao01.Products;

public class HelloWorldMessage implements HelloWorld {

    public void escrever () {
        System.out.println("Hello World!");
    }
}