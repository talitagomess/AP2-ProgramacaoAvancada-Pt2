package Questao01.Products;

public interface  HelloWorld {
    public void escrever ();
}